"""
The contents of this file are set up to take in a JSON object called samplejson.json and print to a csv called
samplecsv.csv. The nesting of the JSON for the relevant fields is displayed below and will need to be modified
to handle multiple API call results / chunks of JSON.

"""


import os
import json
import csv

def create_list_from_json(jsonfile):

    with open(jsonfile) as f:
        data = json.load(f)

    data_list = []  

    data_list.append(data['code'])
    data_list.append(data['message'])
    data_list.append(data['data']['summary']['organization_name'])
    data_list.append(data['data']['summary']['ein'])
    data_list.append(data['data']['summary']['address_line_1'])
    data_list.append(data['data']['summary']['city'])
    data_list.append(data['data']['summary']['state'])
    
    board = len(data['data']['operations']['officers_directors_key_employees'])
    for x in range(board):
        data_list.append(data['data']['operations']['officers_directors_key_employees'][x]['name'])
        data_list.append(data['data']['operations']['officers_directors_key_employees'][x]['title'])
        data_list.append(data['data']['operations']['officers_directors_key_employees'][x]['compensation'])

    data_list.append(data['data']['financials']['most_recent_year_financials']['total_revenue'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['expenses_total'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_govt_grants'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_contributions'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_special_events'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_sales'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_other'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['revenue_investments'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['expense_administration'])
    data_list.append(data['data']['financials']['most_recent_year_financials']['expense_fundraising'])
    
    return data_list

def write_csv():
    row = create_list_from_json(f'samplejson.json')
    with open('samplecsv.csv', 'a') as c:
        writer = csv.writer(c)
        writer.writerow(row)
    c.close()
