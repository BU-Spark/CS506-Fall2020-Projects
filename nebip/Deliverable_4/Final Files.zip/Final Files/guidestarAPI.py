"""
This file takes in a a csv as input and reads for a column called Data which contains only
the EINs of charities. These EIN's are passed into the API calls with a 30 second pause after
every 5 calls to account for the throttling limit. The data is written to a .txt file but
should be converted to .json by changing the extension prior to running json_to_csv.py
"""

import requests
import csv
import time
import pandas as pd

# charities = ["enter charity EIN's here or read from CSV"]

charities = pd.read_csv("./data.csv")


charities = charities['Data']
charities = charities["""index"""] # perform in groups of 500 or less because of API limit


def charToJson():

    counter = 1

    for x in charities:
        organization_id = str(x) # convert integer to string for API call

        response = requests.get(f"https://apidata.guidestar.org/premier/v3/{organization_id}",
         headers={
           "Subscription-Key": "secret"
         }
        )

        with open("data.txt", "a") as myfile:
            myfile.write(response.text)

        counter += 1

        if (counter%5 == 0):
            time.sleep(30) # account for throttle

    
            
        
