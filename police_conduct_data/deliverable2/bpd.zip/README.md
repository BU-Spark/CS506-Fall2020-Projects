﻿# README for Data
### Files Included
 - Court Overtime 2014 - 2019.xlsx
 - BPD_personnel_PRR_9_4_2020.xls
 - 2019 City of Boston employee earnings report: publicly available on the Boston Open Data portal

### BPD_personnel_PRR_9_4_2020.xls
Fields of importance:

 - LN,FN - Last Name, First Name - used to join the datasets.
 - Sex - Sex of Officer
 - Ethnic Grp - Ethnic Group of Officer
 - Annual Rt - Annual Rate Officer was paid

### Court Overtime 2014 - 2019.xlsx
Fields of Importance:

 - ID - ID Number of Officer
 - NAME - Last Name, First Name
 - RANK - Officer's Rank 
 - ASSIGNED - Officer's Assignment for this Court Overtime 
 - CHARGED - Who Officer Charged for this Court Overtime 
 - OTDATE - DAY-Mon-YEAR - Date of Court Overtime
 - DESCRIPTION - Text - Type of Court Appearance (Pretrial, Trial, Type of Hearing)
 - WRKDHRS - Integer - Number of Hours Officer spent at court
 - OTHOURS - Integer - Number of Hours Officer paid 

